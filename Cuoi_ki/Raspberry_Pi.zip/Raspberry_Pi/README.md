# Raspberry Pi module

This is the standalone Raspberry Pi client. Copy the entire `Raspberry_Pi`
folder to the Pi; do not copy only `pi/`, because `shared/` and `config/` are
required at runtime.

## Configure

Edit `config/config.yaml`:

- Set `server.client_host` to the PC/laptop's LAN IP address.
- Set `mqtt.broker_host` to the MQTT broker's LAN IP address.
- Keep `camera.mock_hardware: true` for a software-only demo. Set it to
  `false` when the camera, LED GPIO, and BH1750 sensor are connected.
- Set the same `server.static_token` value as the Server module if token
  authentication is enabled there.

The Pi and PC must be able to reach each other, and the configured API and MQTT
ports must be reachable through the network/firewall.

## Install and run

From inside `Raspberry_Pi`:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[pi]"
python -m pi.main
```

The client sends camera frames to the Server over WebSocket and communicates
device status, sensor readings, and commands over MQTT. Captures queued while
offline are stored under `data/offline_photos/` and uploaded after reconnecting.
