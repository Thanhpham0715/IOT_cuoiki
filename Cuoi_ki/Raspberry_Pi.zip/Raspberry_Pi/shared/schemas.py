"""Validated JSON contracts used by the Raspberry Pi client and AI server."""

from typing import Literal

from pydantic import BaseModel, Field


class FrameMeta(BaseModel):
    session_id: str = Field(min_length=1)
    device_id: str | None = None
    frame_id: int = Field(ge=0)
    timestamp: float = Field(gt=0)


class WebSocketAuth(BaseModel):
    type: Literal["auth"] = "auth"
    token: str = ""


class KeyPoint(BaseModel):
    name: str
    x: float = Field(ge=0, le=1)
    y: float = Field(ge=0, le=1)
    visibility: float = Field(ge=0, le=1)


class FeedbackItem(BaseModel):
    body_part: str
    message: str


class GesturePrediction(BaseModel):
    hand_index: int = Field(ge=0)
    gesture: str | None = None
    score: float | None = Field(default=None, ge=0, le=1)
    handedness: str | None = None


class PoseResult(BaseModel):
    session_id: str
    frame_id: int = Field(ge=0)
    pose_score: int = Field(default=0, ge=0, le=100)
    status: Literal["ok", "adjusting", "no_person", "ai_unavailable"]
    keypoints: list[KeyPoint] = Field(default_factory=list)
    feedback: list[FeedbackItem] = Field(default_factory=list)
    ready_to_capture: bool = False
    hand_count: int = Field(default=0, ge=0)
    gestures: list[GesturePrediction] = Field(default_factory=list)
    processing_ms: float = Field(default=0, ge=0)


class DeviceStatus(BaseModel):
    device_id: str = Field(min_length=1)
    status: Literal["online", "offline"]
    version: str | None = None
    timestamp: float | None = None


class LightSensor(BaseModel):
    device_id: str = Field(min_length=1)
    lux: float = Field(ge=0)
    timestamp: float = Field(gt=0)


class LEDCommand(BaseModel):
    command_id: str = Field(min_length=1)
    brightness: int = Field(ge=0, le=100)


class LEDRequest(BaseModel):
    brightness: int = Field(ge=0, le=100)


class LEDAck(BaseModel):
    command_id: str = Field(min_length=1)
    applied: int = Field(ge=0, le=100)
    success: bool = True
    error: str | None = None


class LEDStatus(BaseModel):
    device_id: str = Field(min_length=1)
    brightness: int = Field(ge=0, le=100)
    timestamp: float = Field(gt=0)


class ButtonEvent(BaseModel):
    device_id: str = Field(min_length=1)
    action: Literal["start_session", "manual_capture", "cancel_countdown"]
    timestamp: float = Field(gt=0)


class SessionCreate(BaseModel):
    device_id: str = Field(min_length=1)
    pose_template_id: str | None = None
    effect_id: str = "original"


class SessionInfo(BaseModel):
    session_id: str
    device_id: str
    status: Literal["active", "completed"]
    pose_template_id: str | None = None
    effect_id: str = "original"
    created_at: float
    ended_at: float | None = None


class PhotoMeta(BaseModel):
    photo_id: str
    session_id: str
    pose_template_id: str | None = None
    effect_id: str = "original"
    timestamp: float
    file_path: str
    pose_score: int = Field(default=0, ge=0, le=100)


class HealthResponse(BaseModel):
    status: Literal["ok", "degraded"]
    uptime_sec: float = Field(ge=0)
    connected_devices: int = Field(ge=0)
    ai_available: bool
    mqtt_connected: bool
